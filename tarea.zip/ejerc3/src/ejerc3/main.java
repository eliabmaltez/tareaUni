package ejerc3;
import java.util.Scanner;
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc=new Scanner(System.in);
		
		double y;
		int x=2;
		double c=2.5;
		
		System.out.println("ingrese un numero de x para la ecuacion y=x*c-2");
		x=tc.nextInt();
		y=x*c-2;
		System.out.println("el resltado de la ecuacion es: "+y);

	}

}
