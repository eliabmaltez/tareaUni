package ejerc7;
import java.util.Scanner;
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner tc=new Scanner(System.in);
        
        double c;
        int f;
        double i=0.55;
        
        System.out.println("ingrese una cantidad en grados fahrenheit");
        f=tc.nextInt();
        System.out.println("la cantidad en grados celcius es:" +i*(f-32));
      
     
        
        
	}

}
