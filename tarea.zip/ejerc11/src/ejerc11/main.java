package ejerc11;
import java.util.Scanner;
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	     Scanner tc=new Scanner(System.in);
	     
	     int n;
	     int c;
	    
	     System.out.println("ingrese un numero");
         n=tc.nextInt();
         double r=Math.toRadians(n);
         double g=Math.cos(r);
         System.out.println("el coseno del numero "+n+" es" + " = "+g);
	}

}
