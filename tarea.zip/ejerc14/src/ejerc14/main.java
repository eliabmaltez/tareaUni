package ejerc14;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	     Scanner tc=new Scanner(System.in);
	     
	     double a;
	     double b;
	     double x;
	     
	     System.out.println("ecuacion de primer grado ax+b=0");
	     System.out.println("ingrese un numero para b");
	     b=tc.nextInt();
	     System.out.println("ingrese un numero para a");
	     a=tc.nextInt();
         x=-b/a;
         
         System.out.println("el resultado de la ecuacion es: "+" x= "+x);
	}

}
