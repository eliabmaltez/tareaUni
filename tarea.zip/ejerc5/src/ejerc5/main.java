package ejerc5;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner tc=new Scanner(System.in);
		
		int y;
		int x;
		
		System.out.println("ingrese un numero de x para la ecuacion y=5*(x^4)+2*(x^3)+3*(x^2)+7");
		x=tc.nextInt();
		int a=(int)(Math.pow(x,4));
		int b=(int)(Math.pow(x,3));
		int c=(int)(Math.pow(x,2));
		y=(5*a)+(2*b)+(3*c)+7;
		
		System.out.println("el resltado de la ecuacion es: "+y); 

	}

}
