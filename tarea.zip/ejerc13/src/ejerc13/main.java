package ejerc13;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	     Scanner tc=new Scanner(System.in);
	     
	     double y;
	     double f;
	     double i;
	     int cm;
	     int a,b,c;
	     
	     System.out.println("ingrese la cantidad en yardas");
	     y=tc.nextInt();
	     System.out.println("ingrese la cantidad en pies");
	     f=tc.nextInt();
	     System.out.println("ingrese la cantidad en pulgadas");
	     i=tc.nextInt();
	     
	     System.out.println("la cantidad de yardas en cm es: "+y*91.44);
	     System.out.println("la cantidad de pies en cm es: "+f*30.48);
	     System.out.println("la cantidad de pulgadas en cm es: "+i*2.54);	
	     	  
	     }
		
	}


