package par_impar;
import java.util.Scanner;
public class main {
    static Scanner teclado=new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int y;
		
	System.out.println("ingrese un numero");
	y= teclado.nextInt();
	
	if (y%2 == 0 ) {
		
		System.out.println("el numero es par");
	}
		
	
	else 
		System.out.println("el numero es impar");

	}

}
