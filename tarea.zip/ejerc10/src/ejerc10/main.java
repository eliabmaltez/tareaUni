package ejerc10;
import java.util.Scanner;
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	     Scanner tc=new Scanner(System.in);
	     
	     
	     int m;
	     int a;
	     
	     
	     
	     System.out.println("ingrese la masa: ");
	     m=tc.nextInt();
	     System.out.println("ingrese la acceleracion:  ");
	     a=tc.nextInt();
	     
	     System.out.println("la fuerza es igual: "+m*a+"N");
	}

}
