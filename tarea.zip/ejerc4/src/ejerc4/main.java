package ejerc4;
import java.util.Scanner;
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc=new Scanner(System.in);
		
		int r;
		int n;
		
		System.out.println("ingrese un numero");
        r=tc.nextInt();    
        
        System.out.println(Math.sqrt(r));
	}

}
