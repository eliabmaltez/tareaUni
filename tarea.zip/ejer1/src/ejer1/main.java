package ejer1;
import java.util.Scanner;
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc=new Scanner(System.in);
		
		int b;
		int h;

		System.out.println("ingrese el numero de la base");
		b=tc.nextInt();
		System.out.println("ingrese el numero de la altura");
		h=tc.nextInt();
		System.out.println("la base es: "+b);
		System.out.println("la altura es: "+h);
		System.out.println("el area es: "+b*h);
		

	}

}
