package ejerc2;
import java .util.Scanner;
public class area_perimetro {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc=new Scanner(System.in);
		
		int d;
		double pi=3.1416;
		int r;
		double a;
		double p;
			
		
		
		System.out.println("el perimetro de una circunferencia");
		System.out.println("ingrese el diametro");
		d=tc.nextInt();
		p=pi*d;
		System.out.println("el perimetro es igual a: "+p);
		
		System.out.println("el area de un circulo");
		System.out.println("ingrese el radio");
		r=tc.nextInt();
		a= pi*r;
		System.out.println("el area es igual a: "+a);
		

	}

}
