package ejerc6;
import java.util.Scanner;
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner tc=new Scanner(System.in);
        
        
        double x;
        double y=2.2;
        double z;
        
        System.out.println("ingrese la cantidad de kilogramos");
        x=tc.nextInt();
        z=(x*y);
        System.out.println("la cantidad en libras es: "+z); 
	}

}
