package ejerc12;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	     Scanner tc=new Scanner(System.in);
		int a=0;
		int b=0;
		int n;
		
		
		double p;
		
		System.out.println("ingrese la cantidad de numeros a valorar");
		n=tc.nextInt();
	    
		while (a<n) {
			System.out.println("ingresa la nota");
			n=tc.nextInt();
			b=b+a;
			a++;
			
			}
		
        p=b/n;
        System.out.println("el promedio es: "+p);
	}

}
