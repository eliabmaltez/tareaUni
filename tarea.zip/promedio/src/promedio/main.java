package promedio;
import java.util.Scanner;
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc=new Scanner(System.in);
		
		System.out.println("ingrese la cantidad de numeros");
		
	    
		int cantnum=tc.nextInt();
		int menor=0;
		int mayor=0;
		for (int i=0; i<cantnum; i++) {
			System.out.println("digite el numero en la posicion"+(i+1));
			int temp=tc.nextInt();
			if (i==0) {
				menor=temp;
			    mayor=temp;
			    
			   
			}else if (temp<menor) {
				menor=temp;
				
			}
			if (temp>mayor) {
				mayor=temp;
			}
			
		}
		System.out.println("el numero menor es " +menor );
		System.out.println("el numero mayor es " +mayor );
	

	}

}
