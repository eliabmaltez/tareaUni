/**
 * 
 */
/**
 * @author Jason
 *
 */
module promedio {
}