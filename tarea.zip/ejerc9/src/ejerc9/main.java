package ejerc9;
import java.util.Scanner;
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc=new Scanner(System.in);
		
		
		int a;
		int r;
		double p=3.1416;
		double V;
		
		System.out.println("ingrese el radio");
		r=tc.nextInt();
		System.out.println("ingrese la altura");
		a=tc.nextInt();
		int v=(int)(Math.pow(r,2));
		V=p*v*a;
		System.out.println("el volumen es: "+V+" unidades cuadradas");
		

	}

}
