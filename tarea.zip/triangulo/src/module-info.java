/**
 * 
 */
/**
 * @author Jason
 *
 */
module triangulo {
}