package triangulo;
import java.util.Scanner;
public class main {
   static Scanner teclado=new Scanner (System.in); 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    
		int a,b,c;
		System.out.println("ingrese el primer numero");
		a = teclado.nextInt();
		System.out.println("ingrese el segundo numero");
		b = teclado.nextInt();
		System.out.println("ingrese el tercer numero");
		c = teclado.nextInt();
		
		if (a <= 0 ||  b <= 0 || c <= 0) {
			System.out.println("el triangulo no existe");
		main.main(null);
		}
		if (a == b && b == c) {
			
			System.out.println("el triangulo es equilatero");
			
		} else if (a == b && a!= c){
			System.out.println("el triangulo es isosceles");
			
		} else if (a != b && b == c  ) {
			System.out.println("el triangulo es isosceles");
			
		}else if (a == c && c !=b ) {
			System.out.println("el triangulo es isosceles");
		}
		
		if (a!= b && a!= c && b != c) {
			System.out.println("el triangulo es escaleno");
			
		}
		
	teclado.close();
	}
}


