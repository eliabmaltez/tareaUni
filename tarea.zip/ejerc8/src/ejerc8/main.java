package ejerc8;
import java.util.Scanner;
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc=new Scanner(System.in);
		
		double s;
		double a;
		double b;
		double c;
		
		System.out.println("ingrese el primer lado");
		a=tc.nextInt();
		System.out.println("ingrese el segundo lado");
		b=tc.nextInt();
		System.out.println("ingrese el tercer lado");
		c=tc.nextInt();
		s=(a+b+c)/2;
		double A= Math.sqrt(s *(s - a)* (s - b)*(s - c));
		
		
		System.out.println("el area del traingulo es: "+A);
		

	}

}
