package bisiesto;
import java.util.Scanner;
public class main {
    static Scanner teclado=new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int x;

System.out.println("ingrese el año");
    x= teclado.nextInt();
    if (x%4 ==0 ) {
    	System.out.println("el año es bisiesto");
    } else {
    	System.out.println("el año no es bisiesto");
    }





	}

}
